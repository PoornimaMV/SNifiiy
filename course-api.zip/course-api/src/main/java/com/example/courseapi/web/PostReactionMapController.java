package com.example.courseapi.web;

public class PostReactionMapController {
}
