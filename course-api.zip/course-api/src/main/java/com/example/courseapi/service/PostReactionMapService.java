package com.example.courseapi.service;

public class PostReactionMapService {
}
