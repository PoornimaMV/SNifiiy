package com.example.courseapi.repository;

public interface PostReactionMapRepository {
}
